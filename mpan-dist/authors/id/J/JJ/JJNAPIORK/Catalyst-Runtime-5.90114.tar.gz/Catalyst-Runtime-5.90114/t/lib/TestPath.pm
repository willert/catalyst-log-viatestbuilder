package TestPath;
use strict;
use warnings;
use Catalyst;

__PACKAGE__->setup;

1;
