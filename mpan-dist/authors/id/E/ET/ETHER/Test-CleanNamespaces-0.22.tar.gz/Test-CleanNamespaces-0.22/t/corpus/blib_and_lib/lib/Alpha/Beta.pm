package Alpha::Beta;
1;
