package LWP::DebugFile;
$LWP::DebugFile::VERSION = '6.25';
# legacy stub

1;
